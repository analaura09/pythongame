n1 = int(input('Primeiro valor: '))
n2 = int(input('Segundo valor: '))
opção = 0
while opção !=5:
 print('''[1] somar
[2] multiplicar
[3] maior
[4] novos números
[5] sair do programa ihu''')
opção = str(input( "Qual é a sua opção? "))
print('FIMMMMMM!')
