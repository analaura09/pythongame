from math import trunc
print ('Exercício 116')
num=float(input("Digite um número real para verificar a porção inteira: "))
print (f"A porção inteira de {num} é {trunc(num)}")
