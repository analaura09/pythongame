nome = input('Digite seu nome completo:')
elif 'mormont' or 'MORMONT' in nome:
    print('Parabéns! você pertence a casa Mormont!')
elif 'bolton' or 'BOLTON' in nome:
    print('Parabéns! você pertence a casa Bolton!')
elif 'stark' or 'STARK' in nome:
    print('Parabéns! você pertence a casa Stark!')
elif 'greyjoy' or 'GREYJOY'in nome:
    print('Parabéns! você pertence a casa Greyjoy!')
elif  'frey' or 'FREY' in nome :
    print('Parabéns! você pertence a casa Frey!')
elif 'TULLY' or 'tully' in nome:
    print('Parabéns! você pertence a casa Tully!')
elif 'arryn' or 'ARRYN' in nome :
    print('Parabéns! você pertence a casa Arryn!')
elif 'lannister' or 'LANNISTER' in nome :
    print('Parabéns! você pertence a casa Lannister!')
elif 'targaryen' or 'TARGARYEN' in nome:
    print('Parabéns! você pertence a casa Targaryen!')
elif 'baratheon' or 'BARATHEON' in nome:
    print('Parabéns! você pertence a casa Baratheon!')
elif 'tyrell ' or 'TYRELL' in nome:
    print('Parabéns! você pertence a casa Tyrell!')
elif 'tarly' or 'TARLY' in nome :
    print('Parabéns! você pertence a casa Tarly!')
elif 'martell' or 'MARTELL'in nome :
    print('Parabéns! você pertence a casa Martell!')

