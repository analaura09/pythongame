numero = int(input(" Digite um numero: "))
antecessor = numero - 1
sucessor = numero + 1
print (" o sucessor de", numero, "é", sucessor,"e o antecessor de", numero, 'é', antecessor)
