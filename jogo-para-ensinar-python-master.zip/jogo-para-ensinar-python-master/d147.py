for n in range(1, 51):
    print('.', end=' ')
    if n % 2 == 0:
        print(n, end=' ')
print('ACABOUUUUUUUUUUUUUUUUUUUUUUUUUUUUU')        
