from exe112.utilidadescev import moeda
from exe112.utilidadescev import dado

p= dado.leiaDinheiro("digite o preço: R$")
moeda.resumo(p, 20, 12)