numero = int(input(' Digite um numero: '))
dobro = numero * 2
triplo = numero * 3
raiz = numero ** (1/2)
print(' O dobro de', numero,'é igual a ' , dobro)
print(' O triplo de', numero, 'é igual a', triplo)
print(' A raiz quadrada de', numero,'é igual a ', raiz)
