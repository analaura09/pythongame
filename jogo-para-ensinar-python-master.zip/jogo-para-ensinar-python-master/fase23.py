while True:
    print('=============================')
    print('BEM VINDO A FASE 23 DO MUNDO 4')
    print('=============================')
    print('os desafios dessa fase são:')
    print('116. porçao inteira \n125. trono de ferro \n147. numeros pares \n150. salario do mês \n152. numeros primos  \n185. competiçao de ginastica')
    print('190. media de alunos \n202. fuçao para calcular \n247. numeros impares')
    opçao = ('digite o numero da fase que deseja: ')
    if opçao == 116:
        import d116
    if opçao == 125:
        import d125
    if opçao == 147:
        import d147
    if opçao == 150:
        import d150
    if opçao == 152:
        import d152
    if opçao == 185:
        import d185
    if opçao == 190:
        import d190
    if opçao ==202:
        import d202
    if opçao == 247:
        import d247
        
