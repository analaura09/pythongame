def escreva(msg):
    tam = len(msg) + 4
    print('~'*tam)
    print(f'{msg}')
    print('~'*tam)
escreva('ana laura')
escreva('jogo em python')
escreva('ola pessoinhas')
