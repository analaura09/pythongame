*PROJETO JOGO EM PYTHON*

**<p>Descriçao do projeto</p>**
`o projeto trata de um jogo que busca ensinar a linguagem Python de forma interativa, esse projeto tem essa como ideia principal,
mas pode ser usado tambem como exemplo para pessoas que queiram se aperfeiçoar nessa linguagem. o jogo é divido em 3 mundos, cada mundo tem varias fases e cada
fase tem seus respectivos desafios. As primeiras fases são links de videos, pois são sobre a história da linguagem e as caracteristicas dela.`

**<p>Instalaçao do jogo</p>**
`para executar esse jogo, será necessário a instalaçao do IDLE ou do PYCHARM, que sao as pla
taformas no qual o jogo foi feito, após a instalaçao deverá ser aberto primeiro o arquivo MENU, para entrar no menu do jogo.
Esse jogo pode ser aberto em computadores com o sistema operacional WINDOWS ou LINUX`
<p>links:</p>
<p><a href= "https://www.youtube.com/watch?v=ElRd0cbXIv4" title="tutorial de instalação do PyCharm">Tutorial de instalaçao do PyCharm!</a></p>                                               
<p><a href= "https://www.jetbrains.com/pycharm/download/#section=windows" title="clique e baixe agora!">Baixar o PyCharm! clique aqui!</a></p>
<p><a href= "https://www.python.org/downloads/" title="clique e baixe o IDLE!">Baixar o IDLE! clique aqui!</a></p>
<p><a href="https://www.youtube.com/watch?v=VuKvR1J2LQE" title="tutorial de instalaçao do IDLE">Tutorial de instalação do IDLE!</a></p>

**<p>desenvolvedores</p>**
`as pessoas responsáveis pela confecçao desse jogo são 
Gabriel Klebson, Ana Laura e João Paulo, alunos do curso tecnico de informatica no IFRN de Ceará-Mirim,RN.Tambem tiveram ajuda do
professor e cordenador do curso tecnico de informatica, Adorilson Bezerra`

**<p>licença</p>**
`Licença MIT
Permissão é concedida, gratuitamente, a qualquer pessoa que obtenha uma cópia
deste software e arquivos de documentação associados (o "Software"), para lidar
no Software sem restrições, incluindo, sem limitação, os direitos
usar, copiar, modificar, mesclar, publicar, distribuir, sublicenciar e / ou vender
cópias do Software e para permitir que pessoas a quem o Software esteja
fornecido para tal, sujeito às seguintes condições:
O aviso de copyright acima e este aviso de permissão devem ser incluídos em todos
cópias ou partes substanciais do Software.
O SOFTWARE É FORNECIDO "COMO ESTÁ", SEM GARANTIA DE QUALQUER TIPO, EXPRESSA OU
IMPLÍCITA, INCLUINDO, MAS NÃO SE LIMITANDO ÀS GARANTIAS DE COMERCIALIZAÇÃO,
ADEQUAÇÃO A UM DETERMINADO FIM E NÃO VIOLAÇÃO. EM NENHUMA CIRCUNSTÂNCIA
AUTORES OU DETENTORES DOS DIREITOS AUTORAIS SERÃO RESPONSABILIZADOS POR QUAISQUER REIVINDICAÇÕES, DANOS OU OUTRAS
RESPONSABILIDADE, SEJA UMA AÇÃO DE CONTRATO, DELITO OU OUTRO, DECORRENTE DE,
FORA OU RELACIONADA COM O SOFTWARE OU O USO OU OUTRAS CONCESSÕES NO
PROGRAMAS.`

**<p>BOM JOGO!</p>**
![Obrigada pela atenção](http://clubedosgeeks.com.br/wp-content/uploads/2016/01/dormrm.gif)