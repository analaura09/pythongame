n1 = float(input("primeira nota do aluno: "))
n2 = float(input("Segunda nota do aluno: "))
m = (n1 + n2) / 2
print(" A media do  {} ao {} é igual a {}".format(n1, n2,m)) 
