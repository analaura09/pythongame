frase = str(input('Digite uma frase: ')).strip().upper()
palavras = frase.split()
junto = '' .join(palavras)
print('Voce digitou a frase {}'.format(palavras))
