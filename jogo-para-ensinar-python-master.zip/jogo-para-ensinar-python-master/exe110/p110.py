from exe110 import moeda

p= float(input('digite o preço:R$'))
moeda.resumo(p,20,12)