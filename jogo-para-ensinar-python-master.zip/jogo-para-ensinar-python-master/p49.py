n1 = int(input('digite o numero que voce deseja ver a tabuada: '))
for c in range(1, 11):
    print('{} x {:2} = {}'.format(n1, c, c*n1))
