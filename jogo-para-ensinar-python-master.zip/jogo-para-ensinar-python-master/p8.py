medida = float(input(' Digite uma distancia em metros: '))
cm = medida * 100
mm = medida * 1000
print(' A medida de {}m corresponde a {}cm e {}mm'.format(medida,cm,mm))
 
