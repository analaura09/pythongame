n1 = int(input('digite um numero: '))
c = 0
for c in range(1,n1 +1):
    print('')
    c += 1
