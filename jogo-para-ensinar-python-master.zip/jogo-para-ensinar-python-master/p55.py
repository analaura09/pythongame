for c in range (1,6):
    list = []
    list.append(float(input('digite o peso de uma pessoa: ')))
ordem = list.sort()
print(' o maior peso lido foi de {}'.format(list[5]))
print(' o menor peso lido foi de {}'.format(list[0]))
