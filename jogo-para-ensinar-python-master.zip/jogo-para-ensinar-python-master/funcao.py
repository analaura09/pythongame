def media (alunos, turmas):
    mediat= alunos/turmas
    return mediat
