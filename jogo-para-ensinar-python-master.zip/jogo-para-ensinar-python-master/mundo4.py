print('======================================')
print('=== BEM VINDO AO MUNDO 4- MONTANHA  ===')
print('=== AS FASES DESSES MUNDO SAO ===')
print('fase 23. A prova de fogo')
opçao=input('você deseja entrar nessa fase?[sim/nao]')
if opçao == 'sim' or 'SIM':
    import fase23
else:
    import menu

